# M68k Mac Reversing Tools (Binary Ninja and Ghidra)

## Binary Ninja Instructions

**Advantage(s)**: Correct calling convention for syscalls, stack-based syscalls are nice

**Disadvantage(s)**: Thunks in the jumptable don't automatically update name/function prototype

1. Make a dump using [dump.py](dump.py).
2. Add [binary_ninja/loader](binary_ninja/loader) and [https://github.com/ubuntor/binaryninja-m68k](https://github.com/ubuntor/binaryninja-m68k) to Binary Ninja plugins.
3. Open the dump. The loader should run automatically and start disassembling.

## Ghidra Instructions

**Advantage(s)**: Syscalls are functions (so xrefs work), nicer handling of thunks

**Disadvantage(s)**: Stack-based syscall arguments are ugly

1. Generate a dump from an executable using [dump.py](dump.py).
2. Put the files in [ghidra/processor](ghidra/processor) in `$GHIDRA_INSTALL/Ghidra/Processors/68000/data/languages/`.
3. Put the files in [ghidra/data](ghidra/data) in `$GHIDRA_INSTALL/Ghidra/Features/Base/data/`.
4. Put the files in [ghidra/scripts](ghidra/scripts) in `$GHIDRA_INSTALL/Ghidra/Features/Base/ghidra_scripts`.
   In Ghidra's _Script Manager_, they will show up in the `Analysis/M68k` category.
   -or-
   Open Ghidra and add the scripts in [ghidra/scripts](ghidra/scripts) to the _Script Manager_ using
   button _Manage Script Directories_. Once added, they will show up in the `Analysis/M68k` category.
5. Open Ghidra and import the generated dump using _File -> Import File..._ (for _Language_, select
   processor `68000`, variant `Mac`)
6. Open the imported dump in Ghidra's CodeBrowser
7. Skip analysis (the scripts in step 8. will take care of this)
8. Run the following scripts in this particular order:
   `M68kMacJankLoader.java` (find functions from jumptable)
   `M68kMacSymbols.java` (find symbols)
   `M68kMacPropagateThunks.java` (propagate thunk calls)
   `M68kMacSyscallScript.java` (markup syscalls)

## TODO
* `_FP68K` (and `_*Dispatch`, `_Pack*`, etc.) routine number labelling
* Finish all syscalls
* Direct loader for Ghidra from binhex/derez
