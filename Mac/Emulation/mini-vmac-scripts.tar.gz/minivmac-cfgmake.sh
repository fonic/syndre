#!/usr/bin/env bash

# ------------------------------------------------------------------------------
#                                                                              -
#  Configure and compile Mini vMac                                             -
#                                                                              -
#  Created by Fonic <https://github.com/fonic>                                 -
#  Date: 09/17/25 - 09/17/25                                                   -
#                                                                              -
#  Based on:                                                                   -
#  https://beyondloom.com/blog/thinkc.html                                     -
#  https://www.gryphel.com/c/minivmac/options.html                             -
#                                                                              -
#  NOTE:                                                                       -
#  Mini vMac can only be configured at COMPILE TIME (machine                   -
#  type to be emulated, screen resolution, color more, etc.)                   -
#                                                                              -
# ------------------------------------------------------------------------------

# Globals
SCRIPT_DIR="$(dirname -- "$(realpath -- "$0")")"
EXAMPLE_OPTS="-t lx64 -m II -hres 960 -vres 600 -depth 3 -magnify 1 -speed 3 -bg 1"

# Print error and exit [$1: message, $2: exit code [optional]]
function die() {
	echo "Error: $1, aborting."
	exit ${2:-1}
}

# Process command line
if ! (( $# > 0 )); then
	echo "Usage:   ${0##*/} OPTIONS"
	echo "Example: ${0##*/} ${EXAMPLE_OPTS}"
	exit 2
fi

# Configure and build
cd -- "${SCRIPT_DIR}" || die "failed to change directory to '${SCRIPT_DIR}'"
if [[ ! -f setup_t ]]; then
	cc setup/tool.c -o setup_t || die "failed to compile setup tool 'setup_t'"
fi
./setup_t "$@" > setup.sh && chmod +x setup.sh || die "failed to generate setup script 'setup.sh'"
./setup.sh || die "failed to run setup script 'setup.sh'"
make || die "failed compile Mini vMac"
