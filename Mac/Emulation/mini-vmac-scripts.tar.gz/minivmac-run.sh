#!/usr/bin/env bash

# ------------------------------------------------------------------------------
#                                                                              -
#  Run Mini vMac                                                               -
#                                                                              -
#  Created by Fonic <https://github.com/fonic>                                 -
#  Date: 09/17/25 - 09/18/25                                                   -
#                                                                              -
#  Based on:                                                                   -
#  https://beyondloom.com/blog/thinkc.html                                     -
#  https://www.gryphel.com/c/minivmac/options.html                             -
#                                                                              -
#  NOTE:                                                                       -
#  To setup a new empty HDD image, first use dd:                               -
#  $ dd if=/dev/zero of=hdd.img bs=1M count=500                                -
#  Then run Mini vMac with a bootable floppy:                                  -
#  $ ./minivmac "System75/Install Disk 1.dsk"                                  -
#  Then DRAG & DROP the newly created HDD image onto the                       -
#  Mini vMac window and follow the on-screen instructions.                     -
#                                                                              -
# ------------------------------------------------------------------------------

# Globals
SCRIPT_DIR="$(dirname -- "$(realpath -- "$0")")"

# Process command line
if ! (( $# > 0 )); then
	echo "Usage:   ${0##*/} DISK-IMAGE..."
	echo "Example: ${0##*/} hdd75.img floppy.dsk"
	exit 2
fi

# Run Mini vMac
cd -- "${SCRIPT_DIR}" || { echo "Error: failed to change directory to '${SCRIPT_DIR}', aborting."; exit 1; }
./minivmac "$@" &
