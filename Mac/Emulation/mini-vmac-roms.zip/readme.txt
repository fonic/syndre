
Put these files next to the Mini vMac executable
(without changing their file names!)
