RPCEmu
~~~~~~

RPCEmu is an emulator of Acorn's Risc PC and A7000 machines. It is a work in
progress and should be considered of Alpha Quality.

The latest version is available from, this also has links to compilation
instructions for various platforms.

    http://www.marutan.net/rpcemu/

The User Manual is available from

    http://www.marutan.net/rpcemu/manual/

RPCEmu requires a RISC OS ROM image to work; check here for details:

    http://www.marutan.net/rpcemu/manual/romimage.html

RPCEmu is licensed under the GPL, see COPYING for more details.

