#!/bin/sh

qtchooser -run-tool=qmake -qt=5
