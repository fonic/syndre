extern void hfe_init(void);
extern void hfe_load(int drive, const char *fn);
