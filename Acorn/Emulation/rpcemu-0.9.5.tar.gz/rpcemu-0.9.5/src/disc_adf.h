extern void adf_init(void);

extern void adf_load(int drive, const char *fn, int sectors, int size, int dblside, int dblstep, int density, int skew);
