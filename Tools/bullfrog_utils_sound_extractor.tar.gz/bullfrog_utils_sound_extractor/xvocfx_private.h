/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef XVOCFX_PRIVATE_H
#define XVOCFX_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"0.1.1.96"
#define VER_MAJOR	0
#define VER_MINOR	1
#define VER_RELEASE	1
#define VER_BUILD	96
#define COMPANY_NAME	""
#define FILE_VERSION	""
#define FILE_DESCRIPTION	"Bullfrog engine VOC sound files extractor"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	""
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"Bullfrog game tools"
#define PRODUCT_VERSION	""

#endif /*XVOCFX_PRIVATE_H*/
