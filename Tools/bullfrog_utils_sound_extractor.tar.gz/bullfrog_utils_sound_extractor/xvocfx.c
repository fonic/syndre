#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bulcommn.h"

// Data types

const int MAX_ITEMS=16384;

typedef struct {
        char filename[14];
        unsigned long startoff;
        unsigned long filesize;
       } EXTRACT_ITEMINFO;

int get_vocpositions(EXTRACT_ITEMINFO *iteminfo,FILE *datfp,unsigned long datfile_length)
{
    static char const voctypeid[] = "Creative Voice File";
    int const vocidsize=sizeof(voctypeid)-1;
    printf("Searching for VOC headers inside DAT...\n");
    char header[vocidsize+1];
    fseek (datfp, 0, SEEK_SET);
    fread (header+1, vocidsize-1, 1, datfp);
    int itemnum=0;
    int pos;
    for (pos=vocidsize-1;pos<datfile_length-31;pos++)
    {
        int n;
        for (n=0;n<vocidsize-1;n++)
           header[n]=header[n+1];
       header[vocidsize-1]=fgetc(datfp);
       //printf("hdr: %s\n",header);
       if (strncmp(header,voctypeid,vocidsize)==0)
       {
           unsigned long start_offset=ftell(datfp)-vocidsize;
           printf("Found VOC identifier at %lu",start_offset);

           fseek (datfp, start_offset+20, SEEK_SET);
           unsigned long data_block_offs=read_short_le_file(datfp);
           if (data_block_offs>255)
           {
               printf(" - bad header, ignored.\n");
               fseek (datfp, start_offset+vocidsize, SEEK_SET);
               continue;
           }
           //Whole data size
           unsigned long data_size=data_block_offs;
           unsigned long data_block_size=0;
           unsigned char data_block_type=0;
           do {
               data_size+=data_block_size;
               fseek (datfp, start_offset+data_size, SEEK_SET);
               data_block_type=fgetc(datfp);
               if (data_block_type>0)
                   data_block_size=(read_long_le_file(datfp)&0x0ffffff)+4;
                 else
                   data_block_size=4;
           } while ((data_block_type>0)&&(!feof(datfp)));
/*
           if (data_size>datfile_length)
           {
                printf(" - data size too large, ignored.\n");
                continue;
           }
*/
           printf(" - accepted.\n");
           //int typenum=-1;
           if (iteminfo[itemnum].filename[0]==0)
               {
               sprintf (iteminfo[itemnum].filename, "bsnd%0*d.%s", 4, itemnum, "voc");
               }
           iteminfo[itemnum].startoff=start_offset;
           iteminfo[itemnum].filesize=data_size+1;
           itemnum++;
           fseek (datfp, start_offset+vocidsize, SEEK_SET);
       }
    }
    return itemnum;
}

int main(int argc, char *argv[])
{

    printf("\nBullfrog engine VOC sound files extractor");
    printf("\n-------------------------------\n");
    if (argc<2)
    {
        printf("Not enought parameters.\n");
        printf("Usage:\n");
        printf("  %s <snddatafile>\n",argv[0]);
        printf("Output: many files\n");
    	return 1;
    }

    //Opening DAT file
    FILE *datfp;
    unsigned long datfile_length;
    {
        char fname[255];
        sprintf (fname, "%s", argv[1]);
        datfp = fopen (fname, "rb");
        if (!datfp)
        {
            printf("Can't open DAT file %s.\n", fname);
        	return 1;
        }

        datfile_length=file_length_opened(datfp);
    }

    EXTRACT_ITEMINFO *iteminfo=malloc(sizeof(EXTRACT_ITEMINFO)*MAX_ITEMS);
    //Clearing
    unsigned long num;
    for (num=0;num<MAX_ITEMS;num++)
        {
        int num2;
        for (num2=0;num2<sizeof(iteminfo[num].filename);num2++)
            iteminfo[num].filename[num2]=0;
        iteminfo[num].startoff=0;
        iteminfo[num].filesize=0;
        }
    //Gets any original file names from DAT headers
    //Disabled, because names go to wrong files.
//    get_filenames(iteminfo,datfp,datfile_length);

    int item_count=get_vocpositions(iteminfo,datfp,datfile_length);
    int itemnum;
    for (itemnum=0;itemnum<item_count;itemnum++)
    {
        unsigned long ifilesize=iteminfo[itemnum].filesize;
        printf("Extracting file %13s, size %7lu ...\n",iteminfo[itemnum].filename,ifilesize);
        //Reading file
        char *filebuf=malloc(ifilesize);
        fseek (datfp, iteminfo[itemnum].startoff, SEEK_SET);
        fread (filebuf, ifilesize, 1, datfp);
        //Writing resulting file
        FILE *outfp;
        outfp = fopen (iteminfo[itemnum].filename, "wb");
        fwrite (filebuf, ifilesize, 1, outfp);
        fclose(outfp);
        free(filebuf);
    }
  printf("Done, %d files extracted.\n",item_count);
  free(iteminfo);
//  system("PAUSE");	
  fclose(datfp);
  return 0;
}
