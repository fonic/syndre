Bullfrog games WAVE/VOC Sound extractors
------------------------------

You need to specify a data file containing sounds.
A load of .wav/.voc files will be created in the current directory.

Usage: xriffx <datafile>
or:    xvocfx <datafile>

Gene Wars example:
xriffx sound.dat

Syndicate example:
xvocfx sound-0.dat

Note that you must decompress compressed files with DERNC
 before extraction.

When extracting VOC files, you will probably want to convert them
 to WAV. Use VOC2WAV. Remember to specify sampling rate!

The source code files comes with Dev-C++ project files, so you can
 easily rebuild the source using Dev-C++ IDE. 

XVOCFX:
Size of extracted files may be smaller than data file up to
 16x(number of VOCs). Last byte of every extracted file should be 0.

Version: 1.10
 Added support of VOC files larger than 65535 (Syndicate Plus SB16 files)

Version: 1.04
 Some minor fixes

Version: 1.00
 First working one

Author:
Tomasz Lis
