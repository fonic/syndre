#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bulcommn.h"

// Data types

const int MAX_ITEMS=16384;

typedef struct {
        char filename[14];
        unsigned long startoff;
        unsigned long filesize;
       } EXTRACT_ITEMINFO;

typedef struct {
        char filename[18];
        char startoff[4];
        char zeros[4];
        char filesize[4];
        char flags[2];
       } DATFILE_TABLEENTRY;

int get_filenames(EXTRACT_ITEMINFO *iteminfo,FILE *datfp,unsigned long datfile_length)
{
    printf("Searching for original file names...\n");
    unsigned long bintable_offs;
        fseek (datfp, -4, SEEK_END);
        bintable_offs=read_long_le_file(datfp);
        if (bintable_offs > datfile_length-406)
        {
            printf("Offset at the end of DAT file exceeds its size: %lu.\n",bintable_offs);
            printf("No original filenames found.\n");
        	return 0;
        }
    //Reading binary table at end
    unsigned long btabsize=datfile_length-bintable_offs;
    char *bintable=malloc(btabsize);
    fseek (datfp, bintable_offs, SEEK_SET);
    fread (bintable, btabsize, 1, datfp);

    unsigned long entrytable_offs=read_long_le_buf(bintable+402);
        if (entrytable_offs > datfile_length-406)
        {
            printf("Offset inside DAT file exceeds its size: %lu.\n",entrytable_offs);
            printf("No original filenames found.\n");
        	return 0;
        }
    //Reading entry table at end
    unsigned long etabsize=bintable_offs-entrytable_offs;
    char *entrytable=malloc(etabsize);
    fseek (datfp, entrytable_offs, SEEK_SET);
    fread (entrytable, etabsize, 1, datfp);
    {
    FILE *outfp;
    outfp = fopen ("etable.dat", "wb");
    fwrite (entrytable, etabsize, 1, outfp);
    fclose(outfp);
    }
    DATFILE_TABLEENTRY *entry;
    unsigned long entry_count=etabsize/sizeof(DATFILE_TABLEENTRY);
    int itemnum=0;
    int entrynum;
    //Enty "0" is just some data, not real file entry.
    for (entrynum=1;entrynum<entry_count;entrynum++)
    {
        entry=(DATFILE_TABLEENTRY *)(entrytable+entrynum*sizeof(DATFILE_TABLEENTRY));
        unsigned long efilesize=read_long_le_buf(entry->filesize);
        int eflags=read_short_le_buf(entry->flags);
        unsigned long estartoff=read_long_le_buf(entry->startoff);
        if (strlen(entry->filename)>2)
        {
        printf("  Found name:%13s",entry->filename);
        int is_unique=1;
        int num;
        for (num=0;num<itemnum;num++)
        {
            if (strncmp(entry->filename, iteminfo[num].filename, 13)==0)
                is_unique=0;
        }
        if (is_unique)
        {
            strncpy(iteminfo[itemnum].filename,entry->filename,13);
            iteminfo[itemnum].filename[13]=0;
            printf(", accepted.\n");
        }
        else
            printf(", already exists.\n");
        itemnum++;
        }
    }
  free(entrytable);
  free(bintable);
  return itemnum;
}


int get_riffpositions(EXTRACT_ITEMINFO *iteminfo,FILE *datfp,unsigned long datfile_length)
{
    static char *const knowntypes[] = {
	"WAVE\0",
	"CDR9\0",
	"AVI\0\0"
    };
    printf("Searching for RIFF headers inside DAT...\n");
    char header[4];
    fseek (datfp, 0, SEEK_SET);
    fread (header+1, 3, 1, datfp);
    int itemnum=0;
    int pos;
    for (pos=3;pos<datfile_length-9;pos++)
    {
       header[0]=header[1];
       header[1]=header[2];
       header[2]=header[3];
       header[3]=fgetc(datfp);
       if (strncmp(header,"RIFF",4)==0)
       {
           unsigned long start_offset=ftell(datfp)-4;
           printf("Found RIFF identifier at %lu",start_offset);
           unsigned long data_size=read_long_le_file(datfp);
           if (data_size>datfile_length)
           {
                printf(" - data size too large, ignored.\n");
                continue;
           }
           char filetype[4];
           fread (filetype, 4, 1, datfp);
           int typenum=-1;
           int num;
           for (num=0;num<sizeof(knowntypes)/sizeof(*knowntypes);num++)
           {
               if (strncmp(filetype, knowntypes[num], 4)==0)
                   typenum=num;
           }
           if (typenum>=0)
           {
            printf(" - %s file, accepted.\n",knowntypes[typenum]);
           }
           else
           {
                printf(" - unknown file type, ignored.\n");
                continue;
           }
           if (iteminfo[itemnum].filename[0]==0)
               {
               char fileext[4];
               strncpy(fileext,knowntypes[typenum],3);
               fileext[3]=0;
               sprintf (iteminfo[itemnum].filename, "bsnd%0*d.%s", 4, itemnum, fileext);
               }
           iteminfo[itemnum].startoff=start_offset;
           iteminfo[itemnum].filesize=data_size+12;
           itemnum++;
       }
    }
    return itemnum;
}

int main(int argc, char *argv[])
{

    printf("\nBullfrog engine RIFF sound files extractor");
    printf("\n-------------------------------\n");
    if (argc<2)
    {
        printf("Not enought parameters.\n");
        printf("Usage:\n");
        printf("  %s <snddatafile>\n",argv[0]);
        printf("Output: many files\n");
    	return 1;
    }

    //Opening DAT file
    FILE *datfp;
    unsigned long datfile_length;
    {
        char fname[255];
        sprintf (fname, "%s", argv[1]);
        datfp = fopen (fname, "rb");
        if (!datfp)
        {
            printf("Can't open DAT file %s.\n", fname);
        	return 1;
        }

        datfile_length=file_length_opened(datfp);
    }

    EXTRACT_ITEMINFO *iteminfo=malloc(sizeof(EXTRACT_ITEMINFO)*MAX_ITEMS);
    //Clearing
    unsigned long num;
    for (num=0;num<MAX_ITEMS;num++)
        {
        int num2;
        for (num2=0;num2<sizeof(iteminfo[num].filename);num2++)
            iteminfo[num].filename[num2]=0;
        iteminfo[num].startoff=0;
        iteminfo[num].filesize=0;
        }
    //Gets any original file names from DAT headers
    //Disabled, because names go to wrong files.
//    get_filenames(iteminfo,datfp,datfile_length);

    int item_count=get_riffpositions(iteminfo,datfp,datfile_length);
    int itemnum;
    for (itemnum=0;itemnum<item_count;itemnum++)
    {
        unsigned long ifilesize=iteminfo[itemnum].filesize;
        printf("Extracting file %13s, size %7lu ...\n",iteminfo[itemnum].filename,ifilesize);
        //Reading file
        char *filebuf=malloc(ifilesize);
        fseek (datfp, iteminfo[itemnum].startoff, SEEK_SET);
        fread (filebuf, ifilesize, 1, datfp);
        //Writing resulting file
        FILE *outfp;
        outfp = fopen (iteminfo[itemnum].filename, "wb");
        fwrite (filebuf, ifilesize, 1, outfp);
        fclose(outfp);
        free(filebuf);
    }
  printf("Done, %d files extracted.\n",item_count);
  free(iteminfo);
//  system("PAUSE");	
  fclose(datfp);
  return 0;
}
