#include <stdio.h>
#include "file.h"

int main(int argc, char **argv)
{
    if (argc < 3) {
        printf("usage: dernc <input> <output>\n");
    }

    int size;
    uint8 *data = File::loadFile(argv[1], size);

    FILE *f = fopen(argv[2], "w");
    if (f == NULL) {
        printf("cannot write to %s\n", argv[2]);
        return 1;
    }
    fwrite(data, size, 1, f);
    fclose(f);

    return 0;
}

